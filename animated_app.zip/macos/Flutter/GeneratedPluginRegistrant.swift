//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import rive_common

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  RivePlugin.register(with: registry.registrar(forPlugin: "RivePlugin"))
}
