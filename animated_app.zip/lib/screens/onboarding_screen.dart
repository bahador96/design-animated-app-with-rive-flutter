import 'package:animated_app/gen/assets.gen.dart';
import 'package:flutter/material.dart';
import 'package:rive/rive.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: const [
          // Assets.riveAssets.shapes.rive(),
          // RiveAnimation.asset('assets/RiveAssets/shapes.riv')
        ],
      ),
    );
  }
}
