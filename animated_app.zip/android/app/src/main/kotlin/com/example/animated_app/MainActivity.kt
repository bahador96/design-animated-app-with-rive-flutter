package com.example.animated_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
