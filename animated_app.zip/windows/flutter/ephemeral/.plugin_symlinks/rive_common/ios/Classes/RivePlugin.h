#import <Flutter/Flutter.h>

@interface RivePlugin : NSObject <FlutterPlugin>
@end
